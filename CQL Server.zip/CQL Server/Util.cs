﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQL_Server
{
    public enum DGViewEditType
    {
        Clean,
        Trim,
        Upper
        
    }

    class Util
    {





    }//Util
}//CQL_Server
